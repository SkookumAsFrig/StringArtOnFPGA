function c = computePixelCodeInPositiveDomain(x, y, domainWidth)
    c = (y - 1) * domainWidth + x;
end