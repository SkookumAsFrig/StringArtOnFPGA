classdef GradientType
    enumeration
        Jet
        Parula
    end
end