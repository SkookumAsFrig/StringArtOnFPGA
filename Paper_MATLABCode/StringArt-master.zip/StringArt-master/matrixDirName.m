function name = matrixDirName(domainWidth, numPins)
    name = ['matrix_' num2str(domainWidth) '_' num2str(numPins) 'Pins'];
end