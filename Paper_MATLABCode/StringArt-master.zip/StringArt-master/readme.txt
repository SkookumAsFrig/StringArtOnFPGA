String Art

Simply start one of the example files, e.g. example_einstein.m

Enjoy!