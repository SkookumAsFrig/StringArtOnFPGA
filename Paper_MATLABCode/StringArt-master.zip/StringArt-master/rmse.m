function rmseValue = rmse(x, y)
    rmseValue = sqrt(mse(x, y));
end